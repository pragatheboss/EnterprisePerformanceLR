Action()
{

	web_url("device-desc.xml", 
		"URL=http://192.168.1.121:8008/ssdp/device-desc.xml", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=application/xml", 
		"Referer=", 
		"Snapshot=t24.inf", 
		LAST);

	web_set_sockets_option("SSL_VERSION", "AUTO");

	lr_think_time(5);

	web_url("seed", 
		"URL=https://clientservices.googleapis.com/chrome-variations/seed?osname=win&channel=stable&milestone=101", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	web_add_cookie("CONSENT=YES+srp.gws-20220309-0-RC1.en+FX+789; DOMAIN=accounts.google.com");

	web_add_cookie("SMSV=ADHTe-B4G-EUhOfBjhjdOeXkcOFYt75ltHy49Xfij7dPqc-VnyKV_zxKzrcPLhRclH1_KPS-Oj0enZZqMivCZQnWUqmGgQJYJqp_TjfWpU0dU2gmufV1jnI; DOMAIN=accounts.google.com");

	web_add_cookie("ACCOUNT_CHOOSER=AFx_qI5G0f8zjQ4kd9MOXlvLhCKr5y0crYddefAPzYPk78Q8YxMqc-neTmn1fEn8WFaNwdmi2cVPnK4WqIoJGOYs1UIUACGIn1sXfBPKMw3SuKPKIsRAOGIO_T4bD5YDXhzudcXqQpY5bQLmsqEwAPNPxzEIZTBE2w; DOMAIN=accounts.google.com");

	web_add_cookie("SEARCH_SAMESITE=CgQIgJUB; DOMAIN=accounts.google.com");

	web_add_cookie("SID=KAiVm3UzVuOJuf2NKRVgfoxFS-u2vQCkN-JsGkS1YWeAxW80gefm6564FEidtQlePZ6aWw.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PSID=KAiVm3UzVuOJuf2NKRVgfoxFS-u2vQCkN-JsGkS1YWeAxW80qhdDrfl7eUfZvzSh0fDPuQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSID=KAiVm3UzVuOJuf2NKRVgfoxFS-u2vQCkN-JsGkS1YWeAxW801UHRnxMOvW39NBL7FMIp5g.; DOMAIN=accounts.google.com");

	web_add_cookie("HSID=A4i43MtkFsn-5rDjq; DOMAIN=accounts.google.com");

	web_add_cookie("SSID=AryQjyxC0uDaQB_Ys; DOMAIN=accounts.google.com");

	web_add_cookie("APISID=rcus5smFFJAimV4z/AWmKWjrHATnrU0OK4; DOMAIN=accounts.google.com");

	web_add_cookie("SAPISID=84vCLABwt5BDAF6-/ALsBluzVn7x21eM7d; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-1PAPISID=84vCLABwt5BDAF6-/ALsBluzVn7x21eM7d; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PAPISID=84vCLABwt5BDAF6-/ALsBluzVn7x21eM7d; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-GAPS=1:73sg5d1mgDlpvvs_zp0dfaoVfw1TeWsxrGD_R4HKo1i5sNY8h4x_SP46CET-5oA75BVtekQpc8LwDdpskgS2P_5p3DAqRw:3JkpUjpX2AlAdFdO; DOMAIN=accounts.google.com");

	web_add_cookie("LSID=o.chat.google.com|o.mail.google.com|o.meet.google.com|s.GB|s.youtube:KAiVm6s_Yt0p7N_1Hy1fbBklZfqGu2veGp23jwKAOSnYn9ygHRz6UUM--bllhn1SYrIjFQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-1PLSID=o.chat.google.com|o.mail.google.com|o.meet.google.com|s.GB|s.youtube:KAiVm6s_Yt0p7N_1Hy1fbBklZfqGu2veGp23jwKAOSnYn9ygsHlCiNHLTQoTfLOnsoIPPQ.; DOMAIN=accounts.google.com");

	web_add_cookie("__Host-3PLSID=o.chat.google.com|o.mail.google.com|o.meet.google.com|s.GB|s.youtube:KAiVm6s_Yt0p7N_1Hy1fbBklZfqGu2veGp23jwKAOSnYn9yglhSSNmxQgXn5PWk9s66LLQ.; DOMAIN=accounts.google.com");

	web_add_cookie("AEC=AakniGN5M64d9OOWwyjlbPBn0WXhVXP51CWGn9pN56Jm0V4LmQ2baqE5HQ; DOMAIN=accounts.google.com");

	web_add_cookie("NID=511=T1O1TD7Y8P1MMP7ttsj8C1AiH7U8CzCJ2OB93Ug_ZsTC1HkEc_1ALVFkjE6Wcq6pNOvHTqZ5-XhvmpXN1cHe4nj820ef-th_un31XLBhV4P3Eatqrxs19LaHEtGivHUb--s5YWnF487SXoeejdsHZ-M_kFEYsKH6MFMM8sSuuuGB_3aWnHXGTzgjuww_S_1o5YqQ-JNbb5Ys_My40DZifyx1YldALMbSaU2DTIKH5h-ByNQf-95MGF4uxMvAAV6omqLEr_ektBv33kYsPKhmAaPyE4PLuuI3wAxetuTW2GQ-6LwWA-YH; DOMAIN=accounts.google.com");

	web_add_cookie("1P_JAR=2022-05-30-21; DOMAIN=accounts.google.com");

	web_add_cookie("SIDCC=AJi4QfFywTTLQzP2FWEbRY1bA6w1Fp2qNwdT5TBjRXTtH8vutgdiFxRPkLTdkEU75zAg_k4m1w; DOMAIN=accounts.google.com");

	web_add_cookie("__Secure-3PSIDCC=AJi4QfFpNkYKnB9X6V59COt66OI7YteBcEEknyc1YTu7dRgoii2-j7sJsTx7avarxOrOPSBaEQ; DOMAIN=accounts.google.com");

	web_custom_request("ListAccounts", 
		"URL=https://accounts.google.com/ListAccounts?gpsia=1&source=ChromiumBrowser&json=standard", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"Body= ", 
		LAST);

	web_custom_request("json", 
		"URL=https://update.googleapis.com/service/update2/json?cup2key=11:tVZamVfjCjeNmBHaWbUcMVuknHJ1FAiRtOwLmUy8v5s&cup2hreq=a5c32651cf329180f354becd7c3b1e3362ec1934abf83fd8427ff3e9782257b9", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"request\":{\"@os\":\"win\",\"@updater\":\"chromecrx\",\"acceptformat\":\"crx3\",\"app\":[{\"appid\":\"ghbmnnjooekpmoecnnnilnnbdlolhkhi\",\"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"external\",\"packages\":{\"package\":[{\"fp\":\"1.1f57dab48a51560b9890c8ccd9a26178e70a9b48f209d1ff670e71be6de0df62\"}]},\"ping\":{\"ping_freshness\":\"{7e24a13b-9c96-42ee-bd29-a6baa94918dd}\",\"rd\":5628},\"updatecheck\":{},\"version\":\"1.42.0\"},{\"appid\":\"nmmhkkegccagdldgiimedpiccmgmieda\",\""
		"cohort\":\"1::\",\"enabled\":true,\"installedby\":\"other\",\"packages\":{\"package\":[{\"fp\":\"2.1.0.0.6\"}]},\"ping\":{\"ping_freshness\":\"{81337b2c-07b6-44d5-b1c9-b16a90b299ac}\",\"rd\":5628},\"updatecheck\":{},\"version\":\"1.0.0.6\"}],\"arch\":\"x64\",\"dedup\":\"cr\",\"domainjoined\":false,\"hw\":{\"avx\":true,\"physmemory\":7,\"sse\":true,\"sse2\":true,\"sse3\":true,\"sse41\":true,\"sse42\":true,\"ssse3\":true},\"ismachine\":true,\"lang\":\"en-US\",\"nacl_arch\":\"x86-64\",\"os\":{\"arch"
		"\":\"x86_64\",\"platform\":\"Windows\",\"version\":\"10.0.22000.675\"},\"prodversion\":\"101.0.4951.67\",\"protocol\":\"3.1\",\"requestid\":\"{74c62821-d7b0-483f-86af-6527e5273d99}\",\"sessionid\":\"{393f88df-2c26-471e-a382-1a9019499b3c}\",\"updaterversion\":\"101.0.4951.67\"}}", 
		EXTRARES, 
		"Url=http://automationpractice.com/favicon.ico", "Referer=http://automationpractice.com/index.php", ENDITEM, 
		LAST);

	return 0;
}